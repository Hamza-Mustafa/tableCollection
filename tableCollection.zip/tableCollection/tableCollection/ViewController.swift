//
//  ViewController.swift
//  tableCollection
//
//  Created by Hamza Mustafa on 13/10/2020.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
