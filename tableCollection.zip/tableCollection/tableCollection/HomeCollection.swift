//
//  HomeCollection.swift
//  tableCollection
//
//  Created by Hamza Mustafa on 13/10/2020.
//

import UIKit

class HomeCollection: UICollectionView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
