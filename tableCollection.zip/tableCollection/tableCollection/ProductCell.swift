//
//  ProductCell.swift
//  tableCollection
//
//  Created by Hamza Mustafa on 13/10/2020.
//

import UIKit

class ProductCell: UICollectionViewCell {
    @IBOutlet weak var productImg: UIImageView!
    @IBOutlet weak var productName: UILabel!
}
