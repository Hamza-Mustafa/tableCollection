//
//  ProductCollection.swift
//  tableCollection
//
//  Created by Hamza Mustafa on 13/10/2020.
//

import UIKit

class ProductCollection: UICollectionView , UICollectionViewDelegate, UICollectionViewDataSource{
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.delegate = self
        self.dataSource = self
    }
    
    let imgArray =  [ #imageLiteral(resourceName: "mac1") , #imageLiteral(resourceName: "5") , #imageLiteral(resourceName: "4") , #imageLiteral(resourceName: "2") , #imageLiteral(resourceName: "3") , #imageLiteral(resourceName: "mac1") , #imageLiteral(resourceName: "5") , #imageLiteral(resourceName: "4") , #imageLiteral(resourceName: "2") , #imageLiteral(resourceName: "3") ]
    let productNameArray = ["demo1","demo2","demo3","demo4","demo5","demo6","demo7","demo8","demo9","demo10"]
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return productNameArray.count
    }
    override func numberOfItems(inSection section: Int) -> Int {
        return productNameArray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let row = indexPath.row
        if(row==0){
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProductCell", for: indexPath) as! ProductCell
            cell.productName.text = productNameArray[indexPath.row]
            cell.productImg.image = imgArray[indexPath.row]
            return cell
        }
        else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "ProductCell", for: indexPath) as! ProductCell
            cell.productName.text = productNameArray[indexPath.row]
            cell.productImg.image = imgArray[indexPath.row]
            return cell
        }
    }
}
